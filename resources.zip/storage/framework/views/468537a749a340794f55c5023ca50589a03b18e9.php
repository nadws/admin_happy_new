
    
    <div class="form-group">
        <input type="hidden" id="id_saldo_therapy" value="<?php echo e($id_saldo_therapy); ?>">
        <input type="hidden" id="id_terapi_sebelum" value="<?php echo e($id_terapi); ?>">
        <label for="">Nama Therapist</label>
        <select name="" class="select2" id="namaTerapi">
            <?php $__currentLoopData = $data_tp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($t->id_therapy == $id_terapi ? 'selected' : ''); ?> value="<?php echo e($t->id_therapy); ?>"><?php echo e($t->nama_therapy); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/dt_paket_pasien/viewEditTerapi.blade.php ENDPATH**/ ?>