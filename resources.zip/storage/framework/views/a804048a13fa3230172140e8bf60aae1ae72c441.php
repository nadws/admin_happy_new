<table class="table table-hover" id="table1">
    <thead>
        <tr>
            <th>#</th>
            <th>Nama Therapist</th>
            <th>Nama Paket</th>
            <th>Jumlah Paket</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no+1); ?></td>
            <td>
                <a href="#" class="editSaldo" id_saldo_therapy="<?php echo e($i->id_saldo_therapy); ?>" id_terapi="<?php echo e($i->id_therapy); ?>" member_id="<?php echo e($i->member_id); ?>" id_paket="<?php echo e($i->id_paket); ?>"><?php echo e($i->nama_therapy); ?></a>
            </td>
            <td><?php echo e($i->nama_paket); ?></td>
            <td><?php echo e($i->debit - $i->kredit); ?></td>
            <td>
                <span class="badge bg-<?php echo e($i->debit - $i->kredit != '1' ? 'success' : 'danger'); ?>">
                    <?php echo e($i->debit - $i->kredit != '1' ? 'ok' : 'Paket mau habis'); ?>

                </span>
            <td>
                <a href="#" class="btn btn-primary btn-sm view2" member_id="<?php echo e($i->member_id); ?>"
                    id_paket="<?php echo e($i->id_paket); ?>"><i class="bi bi-folder-check"></i>
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/dt_paket_pasien/view.blade.php ENDPATH**/ ?>