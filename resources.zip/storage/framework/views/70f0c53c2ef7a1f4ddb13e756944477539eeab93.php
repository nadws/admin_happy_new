<div class="modal-header">
    <h4 class="modal-title" id="myModalLabel33">
        Paket : <?php echo e($paket->nama_paket); ?>

    </h4>
    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
        <i data-feather="x"></i> X
    </button>
</div>
<div class="modal-body">
    <table class="table table-hover" id="table1">
        <thead>
            <tr>
                <th>#</th>
                <th>Tanggal</th>
                <th>No Order</th>
                <th>Nama Therapist</th>
                <th>Beli</th>
                <th>Dipakai</th>
                <th>Sisa</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $saldo = 0;
            ?>
            <?php $__currentLoopData = $invoice_tp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $saldo += $i->debit - $i->kredit
            ?>
            <tr>
                <td><?php echo e($no+1); ?></td>
                <td><?php echo e(date('d-m-Y',strtotime($i->tgl))); ?></td>
                <td><?php echo e($i->no_order); ?></td>
                <td><?php echo e($i->nama_therapy); ?></td>
                <td><?php echo e($i->debit); ?></td>
                <td><?php echo e($i->kredit); ?></td>
                <td><?php echo e($saldo); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/dt_paket_pasien/view2.blade.php ENDPATH**/ ?>