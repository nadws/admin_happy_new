
<table>
    <tr>
        <td>#</td>
        <td>Nama</td>
        <td>Member id</td>
        <td>nm terapi</td>
        <td>paket</td>
        <td>jumlah</td>
        <td>dipakai</td>
        <td>sisa</td>
    </tr>
    <?php $__currentLoopData = $dt_pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $detail = DB::select("SELECT a.id_paket, a.id_therapist,  b.nama_paket, c.nama_therapy, sum(a.debit) as debit, sum(a.kredit) as kredit, a.total_rp, a.no_order
            FROM saldo_therapy as a 
            LEFT JOIN dt_paket as b on b.id_paket = a.id_paket
            LEFT JOIN dt_therapy AS c ON c.id_therapy = a.id_therapist
            WHERE a.member_id = '$d->member_id'
            GROUP BY a.id_paket");
            dd($detail);
        ?>
        <tr>
            <td>1</td>
            <td><?php echo e($d->nama_pasien); ?></td>
            <td><?php echo e($d->member_id); ?></td>
        </tr>
        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/s.blade.php ENDPATH**/ ?>