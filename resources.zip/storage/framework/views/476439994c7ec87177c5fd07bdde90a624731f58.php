<h2 class="font-normal">Riwayat perkembangan psikomotorik</h2>
<!-- Step 1 input fields -->
<form id="save_per1">
    <input type="hidden" class="no_order" name="no_order" value="<?php echo e($no_order); ?>">
    <input type="hidden" class="member_id" name="member_id" value="<?php echo e($member_id); ?>">
    <div class="mt-3">
        <div class="row">
            <div class="col-lg-6">
                <table width="100%">
                    <?php $__currentLoopData = $per; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td width="40%"><?php echo e($p->pertanyaan); ?></td>
                            <td width="4%">:</td>
                            <td width="20%">
                                <input type="text" name="jawaban[]" class="form-control" required>
                                <input type="hidden" name="id_pertanyaan[]" value="<?php echo e($p->id_pertanyaan); ?>">
                            </td>
                            <td>&nbsp;Bulan</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
            <div class="col-lg-6">
                <table width="100%">

                    <?php $__currentLoopData = $per2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td width="40%"><?php echo e($p->pertanyaan); ?></td>
                            <td width="4%">:</td>
                            <td width="20%">
                                <input type="text" name="jawaban[]" class="form-control" required>
                                <input type="hidden" name="id_pertanyaan[]" value="<?php echo e($p->id_pertanyaan); ?>">
                            </td>
                            <td>&nbsp;Bulan</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
            <div class="col-lg-4">
                

            </div>

        </div>

    </div>
    <div class="mt-3">
        <button class="btn btn-primary " type="submit" step_number="2">Save</button>
    </div>
</form>
<?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/isiformulir/step1.blade.php ENDPATH**/ ?>