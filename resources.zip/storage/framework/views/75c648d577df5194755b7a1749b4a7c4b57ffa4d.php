<div class="row" id="row<?php echo e($count); ?>">
    <div class="col-lg-3 mt-2">

        <select name="id_therapist[]" id="" class=" form-select">
            <option value="">--Pilih data--</option>
            <?php $__currentLoopData = $therapist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id_therapy); ?>"><?php echo e($p->nama_therapy); ?> </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-lg-3 mt-2">

        <select name="id_paket[]" id="" class=" form-select pilih_paket" count="<?php echo e($count); ?>">
            <option value="">--Pilih data--</option>
            <?php $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id_paket); ?>"><?php echo e($p->nama_paket); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-lg-2 mt-2">

        <input type="number" name="jumlah[]" class="form-control jumlah jumlah<?php echo e($count); ?>" value="1" count="<?php echo e($count); ?>">
    </div>
    <div class="col-lg-3 mt-2">
        <input type="number" name="total_rp[]" class="form-control rp<?php echo e($count); ?>" readonly>
        <input type="hidden" class="form-control jlh<?php echo e($count); ?>">
    </div>
    <div class="col-lg-1 mt-2">
        <a href="#" class="btn btn-sm btn-warning remove_monitoring" count="<?php echo e($count); ?>"><i
                class="bi bi-dash-square-fill"></i></a>
    </div>
</div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/invoice_tp/tambah.blade.php ENDPATH**/ ?>