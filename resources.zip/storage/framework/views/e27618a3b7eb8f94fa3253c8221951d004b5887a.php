<div class="row">
    <div class="col-lg-6">
        <div class="form-group">
            <label for="">Nama Dokter</label>
            <select name="id_dokter" id="" class="choices form-select">
                <option value="">--Pilih dokter--</option>
                <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->id_dokter); ?>"><?php echo e($d->nm_dokter); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    
    <div class="col-lg-6">
        <div class="form-group">
            <label for="">Pembayaran</label>
            <select name="pembayaran" id="" class="form-control choices">
                <option value="">- Pilih pembayaran -</option>
                <option value="CASH">CASH</option>
                <option value="BCA">BCA</option>
                <option value="MANDIRI">MANDIRI</option>
            </select>
        </div>
    </div>
</div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/invoice_periksa/edit.blade.php ENDPATH**/ ?>