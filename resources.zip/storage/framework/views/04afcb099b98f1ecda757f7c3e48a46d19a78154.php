<div class="row">
    <div class="col-lg-12">
        <table class="table" id="table1">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Member ID</th>
                    <th>No Order</th>
                    <th>Nama Pasien</th>
                    <th>Pembayaran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                ?>
                <?php $__currentLoopData = $invoice_tp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($n->tgl))); ?></td>
                    <td><?php echo e($n->member_id); ?></td>
                    <td><?php echo e($n->no_order); ?></td>
                    <td><?php echo e($n->nama_pasien); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($n->pembayaran != 'belum' ? 'primary' : 'warning'); ?>"><?php echo e($n->pembayaran != 'belum' ? "Paid : " . strtoupper($n->pembayaran) :
                            "Unpaid"); ?>

                        </span>
                    </td>

                    <td>
                        <a href="#" id="hapusTerapi" id_invoice="<?php echo e($n->no_order); ?>"
                          class="btn btn-warning btn-sm"><i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/void/loadTerapi.blade.php ENDPATH**/ ?>