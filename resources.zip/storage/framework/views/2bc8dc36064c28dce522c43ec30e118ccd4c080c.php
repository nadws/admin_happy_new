<div class="row">
    <div class="col-lg-12">
        <div class="form-group">
        <label for="">No Rekam Medis</label>
        <select  name="member_id" id="" class="select2 form-select pilih_rek">
            <option value="">--Pilih data--</option>
            <option value="plusPasien"><a href="<?php echo e(route('data_pasien')); ?>">+ Pasien</a></option>
            <?php $__currentLoopData = $dt_pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->member_id); ?>"><?php echo e($d->member_id); ?> - <?php echo e($d->nama_pasien); ?> - <?php echo e($d->tgl_lahir); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    </div>
    
</div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/data-appointment/noMedis.blade.php ENDPATH**/ ?>