<div class="row">
    <div class="col-lg-12">
        <table class="table table-hover">
            <tr>
                <th>Therapist</th>
                <th>Paket</th>
                <th>Jumlah</th>
                <th width="20%">Dipakai</th>
            </tr>
            <?php $__currentLoopData = $invoice_kunjungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $ttl = $i->debit - $i->kredit;
            ?>
            <?php if($ttl > 0): ?>
            <tr>
                <td>
                    <?php echo e($i->nama_therapy); ?>

                    <input type="hidden" name="id_therapist[]" value="<?php echo e($i->id_therapist); ?>">
                </td>
                <td>
                    <?php echo e($i->nama_paket); ?>

                    <input type="hidden" name="id_paket[]" value="<?php echo e($i->id_paket); ?>">
                </td>
                <td><?php echo e($ttl); ?></td>
                <td><input type="number" name="kredit[]" min="0" max="<?php echo e($ttl); ?>" style="text-align: right" class="form-control" value="0"></td>
            </tr>
            <?php endif; ?>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

</div><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/invoice_kunjungan/dt_paket.blade.php ENDPATH**/ ?>