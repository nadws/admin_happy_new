<?php
$user_id = Auth::user()->id;
$sub_m = DB::table('tb_sub_menu')
->where('url', Route::current()->getName())
->first();
?>
<?php if(!empty($sub_m->url)): ?>
<?php
$per = DB::table('tb_permission')
->where('permission', $sub_m->id_sub_menu)
->where('id_user', $user_id)
->first();
?>
<?php endif; ?>
<?php if(empty($per->id_user)): ?>
<script>
    // window.location.href = '<?php echo e(route('login')); ?>';
</script>
<?php endif; ?>

<style>
    .style1 {
        -webkit-appearance: none;
        -moz-appearance: none;
        width: 80px;
        height: 50px;
        cursor: pointer;
        margin-bottom: 10px;
        border-radius: 10px;
    }

    .card {
        background-color: <?=$warna1 ?>;
    }

    .card-header {
        background-color: <?=$warna1 ?>;
    }

    .sidebar-wrapper {
        background-color: <?=$warna1 ?>;
    }

    .btn-primary {
        --bs-btn-bg: <?=$warna3 ?>;
    }

    .sidebar-wrapper .menu .sidebar-item.active>.sidebar-link {
        background-color: <?=$warna3 ?>;
    }

    .btn-warning {
        --bs-btn-bg: <?=$warna4 ?>;
    }
</style>




<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header position-relative">
            <div class="d-flex justify-content-between align-items-center">
                <div class="logo">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        admin
                    </a>
                </div>
                <div class="theme-toggle d-flex gap-2  align-items-center mt-2">
                    
                    <div style="display: none" class="form-check form-switch fs-6">
                        <input class="form-check-input  me-0" type="checkbox" id="toggle-dark">
                        <label class="form-check-label"></label>
                    </div>

                </div>
                <div class="sidebar-toggler  x">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">Menu</li>
                
                
                
                <?php
                $id_user = Auth::user()->id;

                $sub = DB::table('tb_sub_menu')
                ->where('url', Route::current()->getName())
                ->first();
                ?>
                <?php if(empty($sub->url)): ?>
                <?php
                $menu = DB::select(
                "SELECT a.id_user, b.url, c.id_menu, c.icon, c.menu
                FROM tb_permission AS a
                LEFT JOIN tb_sub_menu AS b ON b.id_sub_menu = a.permission
                LEFT JOIN tb_menu AS c ON c.id_menu = b.id_menu
                WHERE a.id_user ='$id_user'
                GROUP BY b.id_menu
                order by c.urutan ASC
                ",
                );
                ?>

                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="sidebar-item has-sub <?php echo e(Request::is($m->url) ? 'active' : ''); ?>">
                    <a href="#" class='sidebar-link'>
                        <i class="<?php echo e($m->icon); ?>"></i>
                        <span><?php echo e($m->menu); ?></span>
                    </a>
                    <?php

                    $menu_p = DB::select(
                    DB::raw(
                    "SELECT b.id_sub_menu,a.id_user, b.url, b.sub_menu, c.id_menu, c.icon, c.menu
                    FROM tb_permission AS a
                    LEFT JOIN tb_sub_menu AS b ON b.id_sub_menu = a.permission
                    LEFT JOIN tb_menu AS c ON c.id_menu = b.id_menu
                    WHERE a.id_user ='$id_user' and b.id_menu = '$m->id_menu' ORDER BY b.urutan ASC
                    ",
                    ),
                    );

                    ?>

                    <ul class="submenu <?php echo e(Request::is($m->url) ? 'active' : ''); ?>">
                        <?php $__currentLoopData = $menu_p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu-item <?php echo e(Request::is($sm->url) ? 'active' : ''); ?>">
                            <a <?php echo e($sm->url == '#' ? 'data-bs-toggle=modal data-bs-target=#theme' : ''); ?>

                                href="<?php echo e($sm->url == '#' ? '#' : route($sm->url)); ?>"><?php echo e($sm->sub_menu); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <?php
                $menu = DB::select(
                "SELECT a.id_user, b.url, c.id_menu, c.icon, c.menu
                FROM tb_permission AS a
                LEFT JOIN tb_sub_menu AS b ON b.id_sub_menu = a.permission
                LEFT JOIN tb_menu AS c ON c.id_menu = b.id_menu
                WHERE a.id_user ='$id_user'
                GROUP BY b.id_menu
                order by c.urutan ASC
                ",
                );
                ?>
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $permission2 = DB::selectOne(
                DB::raw(
                "SELECT a.id_user, a.permission, b.sub_menu, b.url, b.id_menu
                FROM tb_permission AS a
                LEFT JOIN tb_sub_menu AS b ON b.id_sub_menu = a.permission
                WHERE a.id_user ='$id_user' AND a.permission = '$sub->id_sub_menu' ORDER BY b.urutan ASC
                ",
                ),
                );

                ?>

                <li class="sidebar-item has-sub <?php echo e($permission2->id_menu == $m->id_menu  ? 'active' : ''); ?>">
                    <a href="#" class='sidebar-link'>
                        <i class="<?php echo e($m->icon); ?>"></i>
                        <span><?php echo e($m->menu); ?> </span>
                    </a>
                    <?php

                    $menu_p = DB::select(
                    DB::raw(
                    "SELECT b.id_sub_menu,a.id_user, b.url, b.sub_menu, c.id_menu, c.icon, c.menu
                    FROM tb_permission AS a
                    LEFT JOIN tb_sub_menu AS b ON b.id_sub_menu = a.permission
                    LEFT JOIN tb_menu AS c ON c.id_menu = b.id_menu
                    WHERE a.id_user ='$id_user' and b.id_menu = '$m->id_menu' ORDER BY b.urutan ASC
                    ",
                    ),
                    );
                    ?>
                    <ul class="submenu <?php echo e($permission2->id_menu == $m->id_menu  ? 'active' : ''); ?>">
                        <?php $__currentLoopData = $menu_p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="submenu-item <?php echo e(Request::is($sm->url) ? 'active' : ''); ?>">
                            <a <?php echo e($sm->url == '#' ? 'data-bs-toggle=modal data-bs-target=#theme' : ''); ?>

                                href="<?php echo e($sm->url == '#' ? '#' : route($sm->url)); ?>"><?php echo e($sm->sub_menu); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </ul>
        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {


            $(document).on('change', '#warna2', function() {
                $('.warna2').css('background-color', $(this).val())
            })
        });
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/theme/navbar.blade.php ENDPATH**/ ?>