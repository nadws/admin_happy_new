<input type="hidden" name="kd_user" value="<?= $id_user ?>">
<table class="table ">
    <thead>
        <tr>
            <th>Menu</th>
            <th>Sub Menu</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Menu Dashboard</td>
            <td>
                <?php $__currentLoopData = $dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="labdb<?php echo e($v->id); ?>"><?php echo e($v->teks); ?></label>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>
                
                <?php $__currentLoopData = $dashboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $menu_dashboard = DB::table('dashboard_permission')
                            ->where('id_menu_dashboard', $v->id)
                            ->where('id_user', $id_user)
                            ->first()
                ?>
                    <?php if(empty($menu_dashboard->id_menu_dashboard)): ?>
                        <input type="checkbox" name="id_menu_dashboard[]" value="<?php echo e($v->id); ?>" id="labdb<?php echo e($v->id); ?>"><br>
                    <?php else: ?>
                        <input type="checkbox" name="id_menu_dashboard[]" value="<?php echo e($v->id); ?>" id="labdb<?php echo e($v->id); ?>" checked><br>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </td>
            
        </tr>
        <?php foreach ($menu as $m) : ?>

        <tr>
            <td style="vertical-align: middle;">
                <?= $m->menu ?>
            </td>
            <td>
                <?php $sub = DB::table('tb_sub_menu')
                ->where('id_menu', $m->id_menu)
                ->get() ?>
                <?php foreach ($sub as $s) : ?>
                <?= $s->sub_menu ?> <br>
                <?php endforeach ?>
            </td>
            <td>
                <?php foreach ($sub as $s) : ?>

                <?php $menu_p = DB::table('tb_permission')
                ->where('permission', $s->id_sub_menu)
                ->where('id_user', $id_user)
                ->first() ?>

                <?php if (empty($menu_p->permission)) : ?>
                <input type="checkbox" name="permission[]" value="<?= $s->id_sub_menu ?>" id=""><br>
                <?php else : ?>
                <input type="checkbox" name="permission[]" value="<?= $s->id_sub_menu ?>" checked><br>
                <?php endif ?>

                <?php endforeach ?>
            </td>
        </tr>
        <?php endforeach ?>
        <tr>
            <td>Menu Void</td>
            <td>
                <?php $__currentLoopData = $void; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label for="labvoid<?php echo e($v->id); ?>"><?php echo e($v->teks); ?></label>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td>
                
                <?php $__currentLoopData = $void; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $menu_void = DB::table('void_permission')
                            ->where('id_menu_void', $v->id)
                            ->where('id_user', $id_user)
                            ->first()
                ?>
                    <?php if(empty($menu_void->id_menu_void)): ?>
                        <input type="checkbox" name="id_menu_void[]" value="<?php echo e($v->id); ?>" id="labvoid<?php echo e($v->id); ?>"><br>
                    <?php else: ?>
                        <input type="checkbox" name="id_menu_void[]" value="<?php echo e($v->id); ?>" id="labvoid<?php echo e($v->id); ?>" checked><br>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </td>
            
        </tr>
    </tbody>

</table><?php /**PATH C:\Users\user\Documents\LARAVEL ALDI\admin_happy_new\resources\views/user/permission.blade.php ENDPATH**/ ?>